

//nouf Naif Bin Lebdah
func receivesString(_ word : String ) -> String {
    
    var wordstring = ""
    for i in word {
        if i.isUppercase {
            wordstring += i.lowercased()
        } else {
            wordstring += i.uppercased()
        }
        
    }
    return wordstring
}
 receivesString("My name is Ali" )
 receivesString( "Hello" )


func removeNull(_ array : [String]) -> [String] {
    
    var arr  = [String]()
    for i in array {
        if i == "null" {
            continue
        }
        arr.append(i)
    }
    
    return arr
}
removeNull( ["1","2","3","null","4","null","5"] )



func unicNamber(_ arr : [Int]) ->  [Int] {
    var arra = [Int]()
    var x : Int?
    for i in arr {
        if i != x{
            arra.append(i)
        } else {
        
            x = i
        }
      
    }
    
    return arr
    
}
 unicNamber([2,4,6,4,9,6,2])
 

